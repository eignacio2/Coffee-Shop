-- drop existing tables if they exist
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS AuditLog;
DROP TABLE IF EXISTS AccountEntry;
DROP TABLE IF EXISTS MenuItemPromotion;
DROP TABLE IF EXISTS LineItem;
DROP TABLE IF EXISTS `Order`;
DROP TABLE IF EXISTS PreparationStep;
DROP TABLE IF EXISTS Ingredient;
DROP TABLE IF EXISTS Recipe;
DROP TABLE IF EXISTS Promotion;
DROP TABLE IF EXISTS MenuItem;
DROP TABLE IF EXISTS Schedule;
DROP TABLE IF EXISTS InventoryItem;
DROP TABLE IF EXISTS Barista;
DROP TABLE IF EXISTS Manager;
DROP TABLE IF EXISTS Employee;
SET FOREIGN_KEY_CHECKS = 1;

-- Employee Table (with authentication fields)
CREATE TABLE Employee (
  employeeID VARCHAR(50) PRIMARY KEY,
  ssn VARCHAR(20) NOT NULL,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  salary DECIMAL(10, 2) NOT NULL,
  password VARCHAR(100) NOT NULL DEFAULT 'coffee',
  last_login TIMESTAMP NULL,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT email_format CHECK (email REGEXP '^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[A-Za-z]+$')
);

-- Manager Table 
CREATE TABLE Manager ( 
  employeeID VARCHAR(50) PRIMARY KEY,
  ownership_percentage DECIMAL(5, 2),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (employeeID) REFERENCES Employee(employeeID)
    ON UPDATE CASCADE ON DELETE CASCADE
);

-- Barista Table
CREATE TABLE Barista ( 
  employeeID VARCHAR(50) PRIMARY KEY,
  specialty VARCHAR(100),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (employeeID) REFERENCES Employee(employeeID)
    ON UPDATE CASCADE ON DELETE CASCADE
);

-- Schedule Table
CREATE TABLE Schedule (
  scheduleID INT AUTO_INCREMENT PRIMARY KEY,
  employeeID VARCHAR(50) NOT NULL,
  day_of_week INT NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (employeeID) REFERENCES Barista(employeeID)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT valid_schedule CHECK (end_time > start_time)
);

-- inventory table
CREATE TABLE InventoryItem (
  item_ID INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  price_per_unit DECIMAL(10, 2) NOT NULL,
  amount_in_stock DECIMAL(10, 2) NOT NULL,
  unit VARCHAR(20) NOT NULL,
  min_stock_level DECIMAL(10, 2),
  supplier_info TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- menu items
CREATE TABLE MenuItem (
  menuItem_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  type VARCHAR(100) NOT NULL CHECK (type IN ('coffee', 'tea', 'softdrink', 'food', 'other')),
  size VARCHAR(100),
  temp VARCHAR(10),
  price DECIMAL(10, 2) NOT NULL,
  cost DECIMAL(10, 2),
  description TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT positive_price CHECK (price > 0),
  CONSTRAINT temp_check CHECK (temp IN ('hot', 'cold', 'both') OR temp IS NULL)
);

-- promotions
CREATE TABLE Promotion (
  promotion_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  day_of_week INT,
  discount_price DECIMAL(10, 2),
  discount_percent DECIMAL(5, 2),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT valid_dates CHECK (end_date >= start_date),
  CONSTRAINT day_check CHECK (day_of_week BETWEEN 1 AND 7 OR day_of_week IS NULL),
  CONSTRAINT discount_check CHECK (
    (discount_price IS NOT NULL AND discount_percent IS NULL) OR
    (discount_price IS NULL AND discount_percent IS NOT NULL)
  )
);

-- Recipes
--time in minutes
CREATE TABLE Recipe (
  recipe_id INT AUTO_INCREMENT PRIMARY KEY,
  menuItem_id INT NOT NULL UNIQUE,
  instructions TEXT NOT NULL,
  prep_time INT, 
  active_time INT, 
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (menuItem_id) REFERENCES MenuItem(menuItem_id)
    ON UPDATE CASCADE ON DELETE CASCADE
);

-- Ingredients
CREATE TABLE Ingredient (
  ingredient_id INT AUTO_INCREMENT PRIMARY KEY,
  recipe_id INT NOT NULL,
  item_ID INT NOT NULL,
  quantity DECIMAL(10, 2) NOT NULL,
  unit VARCHAR(20) NOT NULL,
  notes TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (recipe_id) REFERENCES Recipe(recipe_id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  FOREIGN KEY (item_ID) REFERENCES InventoryItem(item_ID)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT positive_quantity CHECK (quantity > 0)
);

-- Preparation Steps
CREATE TABLE PreparationStep (
  step_id INT AUTO_INCREMENT PRIMARY KEY,
  recipe_id INT NOT NULL,
  step_name VARCHAR(255) NOT NULL,
  step_order INT NOT NULL,
  instructions TEXT NOT NULL,
  time_estimate INT, -- in seconds
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (recipe_id) REFERENCES Recipe(recipe_id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT valid_step_order CHECK (step_order > 0)
);

-- Orders 
CREATE TABLE `Order` (
  order_id INT AUTO_INCREMENT PRIMARY KEY,
  order_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  payment_method VARCHAR(50) NOT NULL CHECK (payment_method IN ('cash', 'credit', 'debit', 'mobile', 'giftcard')),
  total_price DECIMAL(10, 2) NOT NULL,
  tax_amount DECIMAL(10, 2) NOT NULL,
  discount_amount DECIMAL(10, 2) DEFAULT 0,
  employeeID VARCHAR(50) NOT NULL,
  customer_notes TEXT,
  status VARCHAR(20) DEFAULT 'completed' CHECK (status IN ('pending', 'preparing', 'completed', 'cancelled')),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (employeeID) REFERENCES Employee(employeeID),
  CONSTRAINT co_positive_total CHECK (total_price > 0)
);

-- Line Items table (updated reference)
CREATE TABLE LineItem (
  lineItem_id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  menuItem_id INT NOT NULL,
  quantity INT NOT NULL CHECK (quantity > 0),
  unit_price DECIMAL(10, 2) NOT NULL,
  promotion_id INT,
  special_instructions TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES `Order`(order_id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  FOREIGN KEY (menuItem_id) REFERENCES MenuItem(menuItem_id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  FOREIGN KEY (promotion_id) REFERENCES Promotion(promotion_id)
    ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT lineitem_positive_price CHECK (unit_price >= 0)
);

-- Menu Item Promotions
CREATE TABLE MenuItemPromotion (
  menuItem_id INT NOT NULL,
  promotion_id INT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (menuItem_id, promotion_id),
  FOREIGN KEY (menuItem_id) REFERENCES MenuItem(menuItem_id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  FOREIGN KEY (promotion_id) REFERENCES Promotion(promotion_id)
    ON UPDATE CASCADE ON DELETE CASCADE
);

-- account entries
CREATE TABLE AccountEntry (
  entryID INT AUTO_INCREMENT PRIMARY KEY,
  transaction_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  amount DECIMAL(10, 2) NOT NULL,
  description VARCHAR(255) NOT NULL,
  balance DECIMAL(10, 2) NOT NULL,
  employeeID VARCHAR(50) NOT NULL,
  transaction_type VARCHAR(50) CHECK (transaction_type IN ('sale', 'expense', 'investment', 'adjustment')),
  reference_id VARCHAR(100),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (employeeID) REFERENCES Employee(employeeID)
);

-- Create indexes for performance
CREATE INDEX idx_employee_email ON Employee(email);
CREATE INDEX idx_order_employee ON `Order`(employeeID);
CREATE INDEX idx_order_time ON `Order`(order_time); 
CREATE INDEX idx_lineitem_order ON LineItem(order_id);
CREATE INDEX idx_lineitem_menu ON LineItem(menuItem_id);
CREATE INDEX idx_inventory_active ON InventoryItem(is_active);
CREATE INDEX idx_menu_active ON MenuItem(is_active);