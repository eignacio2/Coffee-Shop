##Ethan Ignacio
##Fiza Bajwa
##Nandana Devarajan
#CS 480 Coffee Shop App

import mysql.connector
from mysql.connector import Error
import decimal
from getpass import getpass
from decimal import Decimal, InvalidOperation

# database connection configuration
db_config = {
    'host': '127.0.0.1',
    'user': 'root',
    'password': 'YES',  # MySQL password
    'database': 'coffee_shop',       # coffee database 
}
#mySQL db connection
def create_connection():
    """Create a database connection"""
    try:
        connection = mysql.connector.connect(**db_config)
        return connection
    except Error as e: #connection error
        print(f"Error connecting to MySQL: {e}")
        return None
#display menu options
def display_menu(connection):
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT m.menuItem_id as id, m.name, m.price, 
                   GROUP_CONCAT(p.name SEPARATOR ', ') as promotions
            FROM MenuItem m
            LEFT JOIN MenuItemPromotion mp ON m.menuItem_id = mp.menuItem_id
            LEFT JOIN Promotion p ON mp.promotion_id = p.promotion_id
            WHERE m.is_active = TRUE
            GROUP BY m.menuItem_id
        """)
        
        # store results in a list
        menu_items = list(cursor)
        
        print("\nMENU")
        for item in menu_items:
            promo_text = f" (Promo: {item['promotions']})" if item['promotions'] else "" #display promotions
            print(f"{item['id']}. {item['name']} ${item['price']:.2f}{promo_text}")
        
        return menu_items  # Return the stored list
        
    except Error as e:
        print(f"Error loading menu: {e}")
        return []
#display home page for coffee shop app
def home_page(connection):
    """Display the home page"""
    print("\nWelcome to Coffee Shop App")
    menu_items = display_menu(connection)
    print("\nLogin (Enter 'L' to Login)") #input L to login
    
    while True:
        choice = input("Enter your choice: ").upper() 
        if choice == 'L': #if user input is L to login
            login(connection)
            break
        else:
            print("Invalid choice. Please enter 'L' to login.") #invalid input
#user login
def login(connection):
    print("\nLOGIN") #prompts user for email and password
    email = input("Enter your email: ")
    password = input("Enter your password: ")
    
    try:
        cursor = connection.cursor(dictionary=True)
        
        # Check Employee table to see if user is a manager or barista
        cursor.execute("""
            SELECT e.*, 
                   CASE WHEN m.employeeID IS NOT NULL THEN 'manager'
                        WHEN b.employeeID IS NOT NULL THEN 'barista'
                        ELSE NULL END as role
            FROM Employee e
            LEFT JOIN Manager m ON e.employeeID = m.employeeID
            LEFT JOIN Barista b ON e.employeeID = b.employeeID
            WHERE e.email = %s AND e.password = %s
        """, (email, password))
        
        user = cursor.fetchone()
        
        if user: #reads input, checks if user is barista or manager, takes them to appropriate dashboard
            print(f"\nWelcome, {user['name']} ({user['role']})!")
            if user['role'] == 'manager':
                manager_dashboard(connection)
            elif user['role'] == 'barista':
                barista_dashboard(connection, user['employeeID'])
        else:
            print("Invalid email or password.") #if not found in db
            
    except Error as e:
        print(f"Database error: {e}")

def barista_dashboard(connection, barista_id):
    """Display the barista dashboard"""
    while True:  # while loop to keep showing dashboard
        print("\nBARISTA DASHBOARD")
        print("[C] Create an Order")
        print("[R] Recipes")
        print("[HOME] Return to Home")
        print("[X] Cancel")
        
        choice = input("\nEnter your choice: ").upper()
        
        if choice == 'C': #create order as barista
            success = create_order(connection, barista_id)
            if not success:
                continue  # show dashboard again if order failed
        elif choice == 'R': #display recipes for menu items
            display_recipes(connection)
            if not display_recipes(connection):
                    continue
        elif choice == 'HOME': #return to home page
            home_page(connection)
            break
        elif choice == 'X': #end
            print("Goodbye!")
            exit()
        else:
            print("Invalid choice. Please try again.") #if input is invalid
            

def create_order(connection, barista_id): #barista creating order, display menu in ordered list
    menu_items = display_menu(connection)
    order_items = []
    
    while True:
        choice = input("\nEnter item number (or 'F' to finish): ").strip().upper() #end of order being placed
        
        if choice == 'F':
            break
            
        try:
            item_id = int(choice)
            selected = next((i for i in menu_items if i['id'] == item_id), None)
            
            if selected:
                qty = int(input(f"How many {selected['name']}? ")) #num of items from menu
                if qty <= 0:
                    print("Quantity must be positive")
                    continue
                order_items.append({
                    'menuItem_id': selected['id'],
                    'price': selected['price'],
                    'quantity': qty
                })
                print(f"Added {qty}x {selected['name']}") #add items to order
            else:
                print("Invalid item number")
                
        except ValueError:
            print("Please enter a number or 'F'") #order more or end order
    
    if order_items:
        try:
            # Get payment method 
            while True:
                payment_method = input("\nEnter payment method (credit/cash/debit): ").lower()
                if payment_method in ['credit', 'cash', 'debit']:  #payment methods
                    break
                print("Invalid payment method. Please enter credit, cash, or debit")
            
            cursor = connection.cursor()
            total = sum(item['price'] * decimal.Decimal(item['quantity']) for item in order_items)
            tax_amount = total * decimal.Decimal('0.08') #tax calculation
            
            # check if total is positive
            if total <= 0:
                raise ValueError("Order total must be positive")
            
            #add to order table
            cursor.execute(""" 
                INSERT INTO `Order` 
                (payment_method, total_price, tax_amount, employeeID, status)
                VALUES (%s, %s, %s, %s, 'completed')
            """, (payment_method, total, tax_amount, barista_id))
            
            order_id = cursor.lastrowid
            
            # add line items
            for item in order_items:
                cursor.execute("""
                    INSERT INTO LineItem 
                    (order_id, menuItem_id, quantity, unit_price)
                    VALUES (%s, %s, %s, %s)
                """, (order_id, item['menuItem_id'], item['quantity'], item['price']))
            
            # update inventory with ordered items
            for item in order_items:
                cursor.execute("""
                    UPDATE InventoryItem ii
                    JOIN Ingredient i ON ii.item_ID = i.item_ID
                    JOIN Recipe r ON i.recipe_id = r.recipe_id
                    SET ii.amount_in_stock = ii.amount_in_stock - (i.quantity * %s)
                    WHERE r.menuItem_id = %s
                """, (item['quantity'], item['menuItem_id']))
            
            connection.commit()
            print(f"\nOrder #{order_id} created successfully!")
            print(f"Total: ${total:.2f} (Tax: ${tax_amount:.2f})") #display total  with tax
            print(f"Payment Method: {payment_method.capitalize()}") #prompt user for payment method
            
            # return to dashboard
            input("\nPress Enter to return to dashboard...")
            return True
        #invalid inputs
        except Error as e:
            connection.rollback()
            print(f"Order failed: {e}")
            if "amount_in_stock" in str(e):
                print("Error: Not enough inventory for this order")
            elif "Check constraint" in str(e):
                print("Error: Invalid order data - please check payment method and amounts")
            return False
        except ValueError as e:
            print(f"Error: {e}")
            return False
    
    return False
            
#add items to inventory
def increase_inventory(connection, items):
    """Increase the stock level for a selected InventoryItem"""
    try:
        idx = int(input("\nEnter item number to increase: ")) #prompt user to increase inventory
        itm = items[idx - 1]
    except (ValueError, IndexError):
        print("Invalid selection. Please enter a number from the list.")
        return

    amt_str = input(f"How many {itm['unit']} to add? ").strip()
    try:
        amt = Decimal(amt_str)
    except InvalidOperation:
        print("Please enter a valid number (e.g. 5 or 2.5).")
        return

    if amt <= 0:
        print("Units must be positive.")
        return

    #add
    new_qty = itm['amount_in_stock'] + amt #sum new amount + exisiting amount

    try: #update db
        cursor = connection.cursor()
        cursor.execute("""
            UPDATE InventoryItem
               SET amount_in_stock = %s
             WHERE item_ID = %s
        """, (new_qty, itm['id']))
        connection.commit()
        print(f"Inventory updated: {itm['name']} now has {new_qty} {itm['unit']}.")
        #invalid input
    except Error as e:
        print(f"Error updating inventory: {e}")
        connection.rollback()
#display recipes
def display_recipes(connection):
    """Display all recipes"""
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT menuItem_id, name FROM MenuItem")
        menu_items = cursor.fetchall()
        
        print("\nRECIPES")
        for item in menu_items:
            print(f"\n{item[0]}. {item[1]}:")
            
            # get recipe ingredients
            cursor.execute("""
                SELECT i.name, ri.quantity, i.unit 
                FROM Ingredient ri
                JOIN InventoryItem i ON ri.item_ID = i.item_ID
                JOIN Recipe r ON ri.recipe_id = r.recipe_id
                WHERE r.menuItem_id = %s
            """, (item[0],))
            ingredients = cursor.fetchall()
            
            for ing in ingredients:
                print(f"  - {ing[1]} {ing[2]} of {ing[0]}")
        
        input("\nPress Enter to return to dashboard...")
        return True
        
    except Error as e:
        print(f"Error fetching recipes: {e}")
        return False
    
# if logging in as manager, display manager dashboard
def manager_dashboard(connection):
    """Display the manager dashboard"""
    while True:
        print("\nMANAGER DASHBOARD")
        print("[E] Manage Employees")
        print("[I] Manage Inventory")
        print("[R] View Accounting Reports")
        print("[V] View Ownership Percentages")
        print("[HOME] Return to Home")
        print("[X] Cancel")
    
        choice = input("\nEnter your choice: ").upper()
        
        if choice == 'E': #manage employees, hire, fire, list
            manage_employees(connection)
        elif choice == 'I': #add or list inventory
            manage_inventory(connection)
        elif choice == 'R': #accounting reports
            view_accounting_reports(connection)
        elif choice == 'V': #view manager ownership percentage
            view_ownership(connection)
        elif choice == 'HOME': #return to home
            home_page(connection)
            break
        elif choice == 'X':
            print("Goodbye!") #exit
            exit()
        else:
            print("Invalid choice. Please try again.") #invalid input
#list employees
def list_employees(connection):
    cursor = connection.cursor(dictionary=True)
    cursor.execute("""
        SELECT e.employeeID, e.name,
               CASE WHEN b.employeeID IS NOT NULL THEN 'Barista'
                    WHEN m.employeeID IS NOT NULL THEN 'Manager' END AS type
          FROM Employee e
          LEFT JOIN Barista b ON e.employeeID=b.employeeID
          LEFT JOIN Manager m ON e.employeeID=m.employeeID
        ORDER BY e.employeeID
    """)
    rows = cursor.fetchall()
    if rows:
        print("\nCurrent Employees:")
        for idx, emp in enumerate(rows, start=1):
            print(f"{idx}. {emp['name']} - {emp['type'].capitalize()}")
    else:
        print("\nNo employees found.")

def add_employee(connection): #prompt manager for new employee info to add to db
    cursor = connection.cursor()
    name     = input("Enter Full Name: ").strip()
    email    = input("Enter Email Address: ").strip()
    password = getpass("Enter Password: ").strip()
    ssn      = input("Enter SSN (XXX-XX-XXXX): ").strip()
    emp_type = input("Enter Type (barista/manager): ").lower().strip()
    salary   = float(input("Enter Salary: "))

    # generate next employeeID
    cursor.execute("SELECT employeeID FROM Employee ORDER BY employeeID DESC LIMIT 1")
    last_id = cursor.fetchone()[0]             #  'EMP004' number etc.
    next_num = int(last_id.replace('EMP','')) + 1
    new_id   = f"EMP{next_num:03d}"

    confirm = input("[S] Save  [X] Cancel  Enter your choice: ").upper()
    if confirm != 'S':
        print("Cancelled.")
        return

    try:
        # 1) Insert into Employee db
        cursor.execute("""
            INSERT INTO Employee(employeeID, ssn, name, email, salary, password)
            VALUES(%s,%s,%s,%s,%s,%s)
        """, (new_id, ssn, name, email, salary, password))

        # 2) Into Barista or Manager db
        if emp_type == 'barista':
            cursor.execute("INSERT INTO Barista(employeeID) VALUES(%s)", (new_id,))
        else:
            cursor.execute("INSERT INTO Manager(employeeID) VALUES(%s)", (new_id,))

        connection.commit()
        print("Employee added successfully!") #print message
        list_employees(connection)
    except Error as e: #error
        connection.rollback()
        print("Error adding employee:", e)

#remove employee
def remove_employee(connection):
    cursor = connection.cursor(dictionary=True)
    cursor.execute("""
        SELECT e.employeeID, e.name,
               CASE WHEN b.employeeID IS NOT NULL THEN 'Barista'
                    WHEN m.employeeID IS NOT NULL THEN 'Manager' END AS type
          FROM Employee e
          LEFT JOIN Barista b  ON e.employeeID=b.employeeID
          LEFT JOIN Manager m  ON e.employeeID=m.employeeID
    """)
    rows = cursor.fetchall()
    if not rows:
        print("No employees found.")
        return

    # list them
    for idx, emp in enumerate(rows, start=1):
        print(f"{idx}. {emp['name']} - {emp['type']}")

    sel = int(input("Enter number of employee to remove: "))
    emp = rows[sel-1]
    confirm = input(f"Are you sure you want to remove {emp['name']}? (Y/N): ").upper()
    if confirm != 'Y':
        print("Cancelled.")
        return
    #remove employee from db
    try:
        cursor.execute("DELETE FROM Barista  WHERE employeeID=%s", (emp['employeeID'],))
        cursor.execute("DELETE FROM Manager  WHERE employeeID=%s", (emp['employeeID'],))
        cursor.execute("DELETE FROM Employee WHERE employeeID=%s", (emp['employeeID'],))
        connection.commit()
        print("Employee removed.")
        list_employees(connection)
    except Error as e:
        connection.rollback()
        print("Error removing employee:", e)

def view_ownership(connection): #view manager ownership percentage
    """Display ownership percentages of all managers"""
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT e.name, m.ownership_percentage
            FROM Manager m
            JOIN Employee e ON m.employeeID = e.employeeID
        """)
        rows = cursor.fetchall()
        print("\nMANAGER OWNERSHIP")
        for row in rows:
            print(f"{row['name']}: {row['ownership_percentage']}%")
        input("\nPress Enter to return to dashboard...")
    except Error as e:
        print(f"Error fetching ownership data: {e}")

#modify employees, add, remove, edit ownership
def manage_employees(connection):
    """Manage employees"""
    list_employees(connection)
    while True:
        print("""
MANAGE EMPLOYEES
[A] Add Employee
[R] Remove Employee
[O] Edit Manager Ownership
[B] Back
[HOME] Home
[X] Cancel
        """)
        choice = input("Enter your choice: ").upper()

        if choice == 'A':
            add_employee(connection)
        elif choice == 'R':
            remove_employee(connection)
        elif choice == 'O': #edit manager ownership
            edit_manager_ownership(connection)
        elif choice == 'B':
            return  # back to manager_dashboard loop
        elif choice == 'HOME':
            home_page(connection)
            return
        elif choice == 'X':
            print("Goodbye!")
            exit()
        else:
            print("Invalid choice. Please try again.")

#modify inventory values
def manage_inventory(connection):
    """Manage inventory"""
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT item_ID   AS id,
                   name,
                   price_per_unit,
                   unit,
                   amount_in_stock
              FROM InventoryItem
             WHERE is_active = TRUE
            ORDER BY item_ID
        """)
        items = cursor.fetchall()

        print("\nINVENTORY")
        for i, itm in enumerate(items, 1):
            print(f"{i}. {itm['name']} - ${itm['price_per_unit']:.2f} per {itm['unit']} - Quantity: {itm['amount_in_stock']}")

        print("\n[I] Increase Inventory")
        print("[B] Back")
        print("[X] Cancel")

        while True:
            choice = input("\nEnter your choice: ").upper()
            if choice == 'I':
                increase_inventory(connection, items)
                return     # after update, go back to manager_dashboard loop
            if choice == 'B':
                return     # back to manager_dashboard
            if choice == 'X':
                print("Goodbye!")
                exit()
            print("Invalid choice. Please try again.")

    except Error as e:
        print(f"Error managing inventory: {e}")

def edit_manager_ownership(connection):
    """Edit a manager's ownership percentage"""
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT m.employeeID, e.name, m.ownership_percentage
            FROM Manager m
            JOIN Employee e ON m.employeeID = e.employeeID
        """)
        managers = cursor.fetchall()

        if not managers: #if employee entered is not a manager, only managers have ownership
            print("No managers found.")
            return

        print("\nCURRENT MANAGERS AND OWNERSHIP")
        for i, mgr in enumerate(managers, 1):
            print(f"{i}. {mgr['name']} - {mgr['ownership_percentage']}%")

        selected = int(input("\nEnter the number of the manager to edit: "))
        if selected < 1 or selected > len(managers):
            print("Invalid selection.")
            return

        new_percent = float(input(f"Enter new ownership percentage for {managers[selected-1]['name']}: "))
        if new_percent < 0 or new_percent > 100:
            print("Ownership must be between 0 and 100.")
            return
        #update ownserhsip in db
        cursor.execute(""" 
            UPDATE Manager
            SET ownership_percentage = %s 
            WHERE employeeID = %s
        """, (new_percent, managers[selected - 1]['employeeID']))

        connection.commit()
        print("Ownership percentage updated successfully.")

    except ValueError:
        print("Please enter valid numbers.")
    except Error as e:
        print(f"Database error: {e}")


def view_accounting_reports(connection):
    """Compute revenue, expenses, and net profit"""
    try:
        cursor = connection.cursor(dictionary=True)

        # total revenue from orders
        cursor.execute("SELECT SUM(total_price) AS revenue FROM `Order`")
        revenue = cursor.fetchone()['revenue'] or 0

        # salaries
        cursor.execute("""
            SELECT SUM(e.salary) AS barista_salaries
              FROM Employee e
              JOIN Barista b ON e.employeeID=b.employeeID
        """)
        barista_salaries = cursor.fetchone()['barista_salaries'] or 0

        cursor.execute("""
            SELECT SUM(e.salary) AS manager_salaries
              FROM Employee e
              JOIN Manager m ON e.employeeID=m.employeeID
        """)
        manager_salaries = cursor.fetchone()['manager_salaries'] or 0

        # inventory value
        cursor.execute("""
            SELECT SUM(price_per_unit * amount_in_stock) AS inventory_value
              FROM InventoryItem
        """)
        inventory_value = cursor.fetchone()['inventory_value'] or 0

        total_expenses = barista_salaries + manager_salaries + inventory_value #total expense calculation
        net_profit     = revenue - total_expenses
        #print accounting reoprts
        print("\nACCOUNTING REPORTS")
        print(f"Total Revenue:  ${revenue:,.2f}")
        print(f"Total Expenses: ${total_expenses:,.2f}")
        print(f"Net Profit:     ${net_profit:,.2f}")

        print("\n[B] Back")
        print("[X] Cancel")
        while True:
            choice = input("\nEnter your choice: ").upper()
            if choice == 'B':#back
                return
            if choice == 'X':
                print("Goodbye!") #exit
                exit()
            print("Invalid choice. Please try again.")

    except Error as e:
        print(f"Error generating accounting reports: {e}")
def main():
    """Main function to run the application"""
    connection = create_connection()
    if connection:
        home_page(connection)
        connection.close()

if __name__ == "__main__":
    main()