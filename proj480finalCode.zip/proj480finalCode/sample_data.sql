-- tables by dependencies
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE MenuItemPromotion;
TRUNCATE TABLE PreparationStep;
TRUNCATE TABLE LineItem;
TRUNCATE TABLE `Order`;
TRUNCATE TABLE AccountEntry;
TRUNCATE TABLE Schedule;
TRUNCATE TABLE Ingredient;
TRUNCATE TABLE Recipe;
TRUNCATE TABLE MenuItem;
TRUNCATE TABLE Promotion;
TRUNCATE TABLE Barista;
TRUNCATE TABLE Manager;
TRUNCATE TABLE Employee;
TRUNCATE TABLE InventoryItem;
SET FOREIGN_KEY_CHECKS = 1;

-- inserts sample data in proper dependency order

-- 1. employees (no dependencies)
INSERT INTO Employee (employeeID, ssn, name, email, salary, password) VALUES 
('EMP001', '123-45-6789', 'Ethan Ignacio', 'ethan@coffee.com', 45000.00, 'coffee123'),
('EMP002', '234-56-7890', 'Fiza Bajwa', 'fiza@coffee.com', 38000.00, 'coffee123'), 
('EMP003', '345-67-8901', 'Carol Williams', 'carol@coffee.com', 52000.00, 'coffee123'),
('EMP004', '456-78-9012', 'Nandana Devarajan', 'nandana@coffee.com', 40000.00, 'coffee123');

-- 2. managers (depends on employee)
INSERT INTO Manager (employeeID, ownership_percentage) VALUES 
('EMP003', 15.00),
('EMP004', 10.00);

-- 3. baristas (depends on employee)
INSERT INTO Barista (employeeID, specialty) VALUES 
('EMP001', 'Latte Art'),
('EMP002', 'Iced Beverages');

-- 4. inventory items (no dependencies)
INSERT INTO InventoryItem (item_ID, name, price_per_unit, amount_in_stock, unit) VALUES
(1, 'Coffee Beans', 8.99, 50.00, 'lb'),
(2, 'Milk', 0.33, 500.00, 'oz'),
(3, 'Sugar', 0.15, 200.00, 'oz'),
(4, 'Vanilla Syrup', 2.50, 30.00, 'oz'),
(5, 'Chai Tea Concentrate', 5.00, 40.00, 'oz'),
(6, 'Croissant Dough', 1.25, 100.00, 'unit');

-- 5. menu items (no dependencies)
INSERT INTO MenuItem (menuItem_id, name, type, size, temp, price, description) VALUES
(1, 'Latte', 'coffee', '12oz', 'hot', 4.50, 'Espresso with steamed milk'),
(2, 'Iced Coffee', 'coffee', '16oz', 'cold', 3.75, 'Cold brewed coffee over ice'),
(3, 'Chai Tea Latte', 'tea', '12oz', 'hot', 4.25, 'Spiced black tea with milk'),
(4, 'Croissant', 'food', NULL, NULL, 2.99, 'Buttery flaky pastry'),
(5, 'Cappuccino', 'coffee', '8oz', 'hot', 3.99, 'Espresso with foamed milk');

-- 6. recipes (depends on MenuItem)
INSERT INTO Recipe (recipe_id, menuItem_id, instructions, prep_time, active_time) VALUES
(1, 1, '1. Pull espresso shot\n2. Steam milk\n3. Combine', 5, 3),
(2, 2, '1. Brew coffee\n2. Chill\n3. Pour over ice', 10, 2),
(3, 3, '1. Steam milk\n2. Add chai concentrate\n3. Stir', 4, 2),
(4, 5, '1. Pull espresso shot\n2. Foam milk\n3. Combine with 1:1:1 ratio', 5, 3);

-- 7.inngredients (depends on Recipe and InventoryItem)
INSERT INTO Ingredient (ingredient_id, recipe_id, item_ID, quantity, unit) VALUES
(1, 1, 1, 0.1, 'lb'),   -- Latte: coffee beans
(2, 1, 2, 8.0, 'oz'),    -- Latte: milk
(3, 2, 1, 0.15, 'lb'),   -- Iced Coffee: coffee beans
(4, 3, 5, 2.0, 'oz'),    -- Chai Tea: concentrate
(5, 3, 2, 10.0, 'oz'),   -- Chai Tea: milk
(6, 4, 1, 0.08, 'lb'),   -- Cappuccino: coffee beans
(7, 4, 2, 6.0, 'oz');    -- Cappuccino: milk

-- 8. promotions (no dependencies)
-- Every Tuesday special
-- Monday morning special (winter)
INSERT INTO Promotion (promotion_id, name, start_date, end_date, day_of_week, discount_price) VALUES
(1, 'Tuesday Special', '2025-01-01', '2025-12-31', 2, 3.50),   
(2, 'Monday Special', '2025-01-01', '2025-03-31', 1, 6.00);   

-- 9. MenuItemPromotion (depends on MenuItem and Promotion)
INSERT INTO MenuItemPromotion (menuItem_id, promotion_id) VALUES
(1, 1),  -- Latte on Tuesday special
(4, 1),  -- Croissant on Tuesday special
(5, 2);  -- Cappuccino on Monday special

-- 10. Preparation Steps (depends on Recipe)
INSERT INTO PreparationStep (step_id, recipe_id, step_name, step_order, instructions, time_estimate) VALUES
(1, 1, 'Grind Beans', 1, 'Grind 18g of coffee beans', 60),
(2, 1, 'Pull Shot', 2, 'Extract espresso for 25-30 seconds', 30),
(3, 1, 'Steam Milk', 3, 'Steam milk to 150°F', 45),
(4, 2, 'Brew Coffee', 1, 'Brew 16oz of strong coffee', 300),
(5, 2, 'Chill', 2, 'Refrigerate for 4 hours', 14400),
(6, 4, 'Bake', 1, 'Bake at 350°F for 15 minutes', 900);

-- 11. Schedules (depends on Barista)

INSERT INTO Schedule (scheduleID, employeeID, day_of_week, start_time, end_time) VALUES
(1, 'EMP001', 1, '08:00:00', '16:00:00'),  
(2, 'EMP001', 3, '08:00:00', '16:00:00'),  
(3, 'EMP002', 2, '12:00:00', '20:00:00'), 
(4, 'EMP002', 5, '12:00:00', '20:00:00'); 

-- 12. Account Entries (depends on Employee)
INSERT INTO AccountEntry (entryID, amount, description, balance, employeeID, transaction_type) VALUES
(1, 10000.00, 'Initial investment', 10000.00, 'EMP003', 'investment'),
(2, -500.00, 'Inventory purchase', 9500.00, 'EMP003', 'expense'),
(3, 1200.00, 'Daily sales', 10700.00, 'EMP001', 'sale');

-- 13. Orders (depends on Employee)
INSERT INTO `Order` (order_id, payment_method, total_price, tax_amount, employeeID, status) VALUES
(1, 'credit', 12.50, 1.00, 'EMP001', 'completed'),
(2, 'cash', 7.25, 0.58, 'EMP002', 'completed'),
(3, 'mobile', 4.50, 0.36, 'EMP001', 'completed');

-- 14. LineItems (depends on Order and MenuItem)
-- 2 Lattes
-- 1 Croissant
-- 1 Iced Coffee
-- 1 Croissant

(5, 3, 1, 1, 4.50);  
INSERT INTO LineItem (lineItem_id, order_id, menuItem_id, quantity, unit_price) VALUES
(1, 1, 1, 2, 4.50),  
(2, 1, 4, 1, 2.99),  
(3, 2, 2, 1, 3.75),  
(4, 2, 4, 1, 2.99), 